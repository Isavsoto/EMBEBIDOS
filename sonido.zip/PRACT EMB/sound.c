// === Enumeraciones de notas y duraciones ===
enum Notas {
  NOTA_SILENCIO,
  NOTA_A5,
  NOTA_B5,
  NOTA_C6,
  NOTA_D6,
  NOTA_E6,
  NOTA_A2,
  NOTA_C3,
  NOTA_B2,
  NOTA_G2
};

enum Duracion {
  SEMICORCHEA,
  CORCHEA,
  NEGRA,
  BLANCA,
  REDONDA
};

// === Funci�n central para reproducir una nota ===
void TocarNota(enum Notas nota, enum Duracion duracion) {
  unsigned int frecuencia = 0;
  unsigned int tiempo_ms = 0;

  // Asignar frecuencia seg�n la nota
  switch (nota) {
    case NOTA_A5: frecuencia = 880; break;
    case NOTA_B5: frecuencia = 987 ; break;
    case NOTA_C6: frecuencia = 1046; break;
    case NOTA_D6: frecuencia =1175 ; break;
    case NOTA_E6: frecuencia = 1318; break;
    case NOTA_A2: frecuencia = 220; break;
    case NOTA_C3: frecuencia = 261; break;
    case NOTA_B2: frecuencia = 247; break;
    case NOTA_G2: frecuencia = 207; break;
    case NOTA_SILENCIO: frecuencia = 0; break;
    
    
    
    
    
    
    
    
  }

  // Asignar duraci�n seg�n figura
  switch (duracion) {
    case SEMICORCHEA: tiempo_ms = 125; break;
    case CORCHEA:     tiempo_ms = 50; break;
    case NEGRA:       tiempo_ms = 250; break;
    case BLANCA:      tiempo_ms = 500; break;
  }

  // Ejecutar sonido o silencio
  if (frecuencia == 0){
    switch (duracion) {
        case SEMICORCHEA: Delay_ms(125); break;
        case CORCHEA:     Delay_ms(250); break;
        case NEGRA:       Delay_ms(250); break;
        case BLANCA:      Delay_ms(500); break;
    }
    return;
}
  else
    Sound_Play(frecuencia, tiempo_ms);
}

// === Melod�a b�sica como ejemplo ===
void MelodiaEjemplo() {
  TocarNota(NOTA_A5, NEGRA);
  TocarNota(NOTA_E6, BLANCA);
  TocarNota(NOTA_A5, NEGRA);
  TocarNota(NOTA_E6, BLANCA);
  TocarNota(NOTA_B5, NEGRA);
  TocarNota(NOTA_E6, BLANCA);
  TocarNota(NOTA_B5, NEGRA);
  TocarNota(NOTA_E6, BLANCA);
  TocarNota(NOTA_C6, NEGRA);
  TocarNota(NOTA_E6, BLANCA);
  TocarNota(NOTA_C6, NEGRA);
  TocarNota(NOTA_E6, BLANCA);
  TocarNota(NOTA_D6, NEGRA);
  TocarNota(NOTA_E6, BLANCA);
  TocarNota(NOTA_D6, NEGRA);
  TocarNota(NOTA_E6, NEGRA);
  TocarNota(NOTA_B5, NEGRA);
  TocarNota(NOTA_A5, NEGRA);
  TocarNota(NOTA_E6, BLANCA);
  TocarNota(NOTA_A5, NEGRA);
  TocarNota(NOTA_E6, BLANCA);
  TocarNota(NOTA_B5, NEGRA);
  TocarNota(NOTA_E6, BLANCA);
  TocarNota(NOTA_B5, NEGRA);
  TocarNota(NOTA_E6, BLANCA);
  TocarNota(NOTA_C6, NEGRA);
  TocarNota(NOTA_E6, BLANCA);
  TocarNota(NOTA_C6, NEGRA);
  TocarNota(NOTA_E6, BLANCA);
  TocarNota(NOTA_D6, NEGRA);
  TocarNota(NOTA_E6, BLANCA);
  TocarNota(NOTA_D6, NEGRA);
  TocarNota(NOTA_E6, NEGRA);
  TocarNota(NOTA_B5, NEGRA);
  
}

void lose(){
  TocarNota(NOTA_A2, NEGRA);
  TocarNota(NOTA_A2, NEGRA);
  TocarNota(NOTA_A2, SEMICORCHEA);
  TocarNota(NOTA_A2, NEGRA);
  TocarNota(NOTA_C3, NEGRA);
  TocarNota(NOTA_B2, SEMICORCHEA);
  TocarNota(NOTA_B2, NEGRA);
  TocarNota(NOTA_A2, SEMICORCHEA);
  TocarNota(NOTA_A2, NEGRA);
  TocarNota(NOTA_G2, SEMICORCHEA);
  TocarNota(NOTA_A2, NEGRA);

}

// === Configuraci�n principal del sistema ===
void main() {
  ANSEL  = 0;           // Pines AN como digitales
  ANSELH = 0;
  C1ON_bit = 0;         // Comparadores desactivados
  C2ON_bit = 0;

  TRISB = 0xF8;         // RB7-RB3 como entradas (botones)
  TRISC = 0;            // Puerto C como salida
  PORTC = 0;

  Sound_Init(&PORTC, 3);   // Inicializa RC3 para salida de sonido
  //Sound_Play(880, 1000);   // Sonido de bienvenida

  while (1) {
    if (Button(&PORTB, 7, 1, 1)) TocarNota(NOTA_A5, NEGRA);
    while (RB7_bit);

    if (Button(&PORTB, 6, 1, 1)) TocarNota(NOTA_B5, CORCHEA);
    while (RB6_bit);

    if (Button(&PORTB, 5, 1, 1)) TocarNota(NOTA_D6, CORCHEA);
    while (RB5_bit);

    if (Button(&PORTB, 4, 1, 1)) MelodiaEjemplo();  // Ejecuta peque�a melod�a
    while (RB4_bit);

    if (Button(&PORTB, 3, 1, 1)) Lose();  // Perdio
    while (RB3_bit);
  }
}
